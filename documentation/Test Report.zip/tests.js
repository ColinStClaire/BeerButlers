/**
 * Created by colinstclaire on 11/28/16.
 */
///
//Test, test to make sure that QUnit it working
/*QUnit.test('test1', function(assert) {
   assert.strictEqual(1, 1, "1 === 1");
});
*/
//Second Test, testing the getBrewery to ensure that it reaches the API
